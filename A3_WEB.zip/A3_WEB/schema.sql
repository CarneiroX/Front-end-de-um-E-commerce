



CREATE TABLE IF NOT EXISTS Funcionario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome VARCHAR (20),
    idade INTEGER,
    endereco VARCHAR (100)
);
