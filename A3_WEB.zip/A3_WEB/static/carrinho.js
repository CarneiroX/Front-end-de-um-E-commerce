function remover_item(e) {
  e.parentElement.remove()
}

function calc(n) {
  var preco1 = document.getElementsByClassName("preco_produto_1")[n].innerHTML;
  var quant1 = document.getElementsByClassName("quantidade_1")[n].value;
  var preco2 = document.getElementsByClassName("preco_produto_2")[n].innerHTML;
  var quant2 = document.getElementsByClassName("quantidade_2")[n].value;
  var preco3 = document.getElementsByClassName("preco_produto_3")[n].innerHTML;
  var quant3 = document.getElementsByClassName("quantidade_3")[n].value;
  var desc1 = document.getElementsByClassName("promocao_1")[n].innerHTML;
  var desc2 = document.getElementsByClassName("promocao_2")[n].innerHTML;
  var desc3 = document.getElementsByClassName("promocao_3")[n].innerHTML;
  
  var subtotal1 = parseFloat(preco1) * quant1;
  var subtotal2 = parseFloat(preco2) * quant2;
  var subtotal3 = parseFloat(preco3) * quant3;
  var subtotal = subtotal1 + subtotal2 + subtotal3;
  if (!isNaN(subtotal)){
    document.getElementsByClassName("subtotal")[n].innerHTML = subtotal.toFixed(2);
  }

  var quant = parseInt(quant1) + parseInt(quant2) + parseInt(quant3);
  if (!isNaN(quant)){
    document.getElementsByClassName("quant")[n].innerHTML = quant;
  }

  var desconto1 = parseFloat(desc1) * quant1;
  var desconto2 = parseFloat(desc2) * quant2;
  var desconto3 = parseFloat(desc3) * quant3;
  var desconto = desconto1 + desconto2 + desconto3;
  if (!isNaN(desconto)){
    document.getElementsByClassName("desconto")[n].innerHTML = desconto;
  }

  var total = subtotal - desconto;
  if (!isNaN(total))
    document.getElementsByClassName("total")[n].innerHTML = total.toFixed(2);
}
