document.getElementById("botao").addEventListener(
    "click", function() {alert('foi');}
);
