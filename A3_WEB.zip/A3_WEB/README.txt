Grupo:
Alex Carneiro Martins - RA: 125111370659
Leonardo Felipe Ventura Ferreira - RA: 125111348589
Luigi Guilherme R. da Silva - RA: 125111365839
Silvio Augusto Oliveira de Goes - RA: 12522221587
Solomao Sung Min Hwang - RA: 125111359770
Vinicius dos Santos Souza - RA: 125111364575