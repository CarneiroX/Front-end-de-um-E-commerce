# -*- coding: utf-8 -*-
import sqlite3
from flask import Flask, request, render_template
from flask import g

BANCO_DE_DADOS = './banco.db'

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

def carregar_banco():
    banco = getattr(g, '_database', None)

    if banco is None:
        g._database = sqlite3.connect(BANCO_DE_DADOS)
        banco = g._database
    return banco

def iniciar_tabela():
    banco = carregar_banco()
    script_criacao = open('schema.sql').read()
    banco.executescript(script_criacao)


@app.route('/')
def admin():
    banco = carregar_banco()
    iniciar_tabela()
    return render_template('homepage.html')

@app.route('/carrinho')
def carrinho():
    return render_template('carrinho.html')

@app.route('/Pagamento')
def pagamento():
    return render_template('Pagamento.html')

@app.route('/compra-aprovada')
def resultado_compra():
    return render_template('resultado_compra.html')        

@app.route('/RegataBulls')
def regata_bulls():
    return render_template('RegataBulls.html')

@app.route('/CamisaFila')
def camisa_fila():
    return render_template('CamisaFila.html')

@app.route('/CortaVentoNewEra')
def cortavento_newera():
    return render_template('CortaVentoNewEra.html')

@app.route('/TenisAdidasBranco')
def tenisadida_branco():
    return render_template('TenisAdidasBranco.html')   

@app.route('/TenisAdidasPreto')
def tenisadida_preto():
    return render_template('TenisAdidasPreto.html')

@app.route('/TenisMizunoBranco')
def tenis_mizuno():
    return render_template('TenisMizunoBranco.html')

@app.route('/BolaBasquete')
def bola_basquete():
    return render_template('BolaBasquete.html')

@app.route('/BolaFutebol')
def formulario_bolafutebol():
    return render_template('BolaFutebol.html')

@app.route('/Chuteira')
def chuteira():
    return render_template('Chuteira.html')               

@app.route('/admin')
def formulario_admin():
    return render_template('admin.html')

@app.route('/formulario_insere.html')
def formulario_insercao():
    return render_template('formulario_insere.html')

@app.route('/add', methods = ['POST',])
def salvar_info():
    banco = carregar_banco()
    cur = banco.cursor()

    nome = request.form["nome"]
    idade = request.form["idade"]
    endereco = request.form["endereco"]

    cur.execute("""
        INSERT INTO Funcionario
               (nome, idade, endereco)
        VALUES (?, ?, ?) """,
        (nome, idade, endereco)
    )
    banco.commit()
    banco.close()
    return render_template('resultado_insere.html')
    #return "Nome: %s, Idade: %s, Endereço: %s" % (nome, idade, endereco)

@app.route('/formulario_atualiza.html')
def formulario_atualiza():
	return render_template('formulario_atualiza.html')

@app.route('/atualizarfuncionario', methods = ['POST',])
def atualizar_funcionario():
    banco = carregar_banco()
    cur = banco.cursor()

    id = request.form["id"]
    nome = request.form["nome"]
    idade = request.form["idade"]
    endereco = request.form["endereco"]
    cur.execute("""
        UPDATE Funcionario
        SET nome=?, idade=?, endereco=?
        WHERE id = ?
        """, (nome, idade, endereco, id)
    ).fetchall()
    banco.commit()
    banco.close()
    return render_template('resultado_atualiza.html')

@app.route('/formulario_busca.html')
def formulario_busca():
    return render_template('formulario_busca.html')

# Essa Rota só visualiza um único Gerente por vez, fazendo a busca pelo ID
@app.route('/ver', methods = ['POST',])
def ver_info():
    banco = carregar_banco()
    cur = banco.cursor()

    id = request.form["id"]
    resultados = cur.execute("""
        SELECT id, nome
        FROM Funcionario
        WHERE id = ?
        """, (id)
    ).fetchall()
    banco.commit()
    banco.close()
    return render_template("resultados_busca.html",
                           resultados=resultados)

# @app.route('/listarfuncionarios')
# def listar_funcionarios():
#     banco = carregar_banco()
#     cur = banco.cursor()

#     resultados = cur.execute("""
#         SELECT id, nome
#         FROM Funcionario """
#     ).fetchall()
#     banco.commit()
#     banco.close()
#     return render_template("resultados_busca.html",
#                            resultados=resultados)